# SQL_Project1

<h2> 1. To all members: </h2>
  <p>To all team members, this project will be implemented using python3 and it's virtual environment (learn more about it <a href="https://packaging.python.org/guides/installing-using-pip-and-virtual-environments/"
  target="_blank">here</a>). This is especially important since python is interpreted and requires libraries, and they will not be on the lab machine.</p>
  
<h2>2. How to work in this environment:</h2>
  <p>
    <li>Create your own branch.</li>
    <li>Do small things.</li>
    <li>When you done the small thing text me I will take a look.</li>
    <li>If everything is good I will copy to the main branch. You will then download the newest version to your PC (git pull) to your PC. This version will have your own 
  newest update, and other teammates' updates. Develope from there.</li>
    <li>DO NOT CHANGE THE MAIN BRANCH.</li>
    <li>Let me know after u finish small things. It is easier to check the code.</li>
=======
    <li>When you done the small thing create a pull request (learn more <a href="https://www.atlassian.com/git/tutorials/making-a-pull-request" target="_blank">here</a>).</li>
    <li>DO NOT CHANGE THE MAIN BRANCH.</li>
    <li>Create pull requests after u finish small things. It is easier to check the code.</li>
>>>>>>> Create README.md
=======
    <li>When you done the small thing text me I will take a look.</li>
    <li>If everything is good I will copy to the main branch. You will then download the newest version to your PC (git pull) to your PC. This version will have your own 
  newest update, and other teammates' updates. Develope from there.</li>
    <li>DO NOT CHANGE THE MAIN BRANCH.</li>
    <li>Let me know after u finish small things. It is easier to check the code.</li>
>>>>>>> Update README.md
  </p>
  
 <h2>3. Update:</h2>
  <p>
    <li>Oct 25th: Created PyCharm structure.</li>
  
  
  </p>
